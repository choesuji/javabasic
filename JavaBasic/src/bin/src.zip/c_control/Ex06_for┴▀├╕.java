package c_control;

public class Ex06_for중첩 {

	public static void main(String[] args) {

		//		for(int j=0; j<5; j++) {   // 5줄 의미
		//		
		//		for (int i = 0 ; i < 5 ; i++ ) {  // 5칸 의미
		//			System.out.print("*");     // printf 하면 가로로 나옴
		//		}
		//		System.out.println();
		//	}

//				for(int j=0; j<5; j++) {   // 5줄까지만 의미
//					
//				for (int i = 0 ; i < (j+1) ; i++ ) {  // 5칸 의미
//					System.out.print("*");     // printf 하면 가로로 나옴
//				}
//				System.out.println();
//			}

//				for (int j = 0; j < 5; j++) { // 5줄 의미
//					for (int i = 0; i < 5 - j; i++) { // 5칸 의미
//						System.out.print("*"); // printf 하면 가로로 나옴
//					}
//					System.out.println();
//				}

////		for (int j = 0; j < 5; j++) { // 5줄
////			// 공백출력
////			for (int i = 0; i < j; i++) {
////				System.out.print(" ");
////			}
//
////			// '*'찍기
//			for (int i = 0; i < 5 - j; i++) { // 5칸
//				System.out.print("*");
//			}
//			System.out.println();
		}

	}

