package a_datatype;

public class Ex05_복습 {

	public static void main(String[] args) {
		
		// 나이를 저장할 변수를 선언하고 본인의 나이를 대입한 후 출력
		int a;
		a = 30;
		System.out.println("내나이 " +a);
		
		
		// 본인의 키를 소수점 포함한 데이타로 저장하고 출력
		double b;
		b = 165.2;
				System.out.println("내키 "+b);
		
		// 이름 저장할 변수를 선언하고 이름을 대입 후 출력
		char name = '홍';
		char name2 = '김';
		char name3 = '홍';
		
		// *******************
		// 문자  : char     -> ''
		// 문자열 : String ( 클래스-참조형)     ->""  / 첫자 대문자 !!!!
		String irum="홍길자";
		System.out.println("이름은 " +irum+ "입니다");
		
		
		
		
		

	}

}
