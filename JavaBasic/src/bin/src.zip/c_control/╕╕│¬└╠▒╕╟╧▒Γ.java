package c_control;

public class 만나이구하기 {

	public static void main(String[] args) {
		// 오늘날짜로 구하기
		// 연,월,일 모두 비교
		
		

	}

}
