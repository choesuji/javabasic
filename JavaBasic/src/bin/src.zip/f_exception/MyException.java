package f_exception;

public class MyException extends Exception {

	public String getMessage() {
		return "우리가 매번 실수하는 배열 예외발생";
	}
}
