package E_method;

/*
 * 문제1) 영문자를 입력하여 이 문자를 넘겨받아 이 문자가 소문자이면 true을 반환 그렇지 않으면
 * false을 반환
 * 함수명 : checkLower
 * 인자 : char
 * 리턴(반환) : boolean
 */
public class Ex05_개념연습 {

	public static void main(String[] args) {
	
			
	}

	static boolean checkLower(char a) {
		
		return true;
	}
	
	
	
//	static boolean checkLower(char a) {  // 함수명 , 인자 
//		//boolean flag = true;
//		
//		return true;  // 반환값 
//		}
	
	
	/*
	 * 문제1) 영문자를 입력하여 이 문자를 넘겨받아 이 문자가 소문자이면 대문자로 변환하여 반환 
	 * 대문자라면 그대로 반환
	 * 함수명 : checkUpper
	 * 인자 : char
	 * 리턴(반환) : char
	 */	
	
	static char checkUpper (char z) {
	char a = 0;
	
	return a;
	
	
	
	
	
	
	
//	static char checkUpper (char z) {
//		// char ch = '\u0000';
//		char ch = '0';
//		
//		return ch;
		
//	}
	
	
}



